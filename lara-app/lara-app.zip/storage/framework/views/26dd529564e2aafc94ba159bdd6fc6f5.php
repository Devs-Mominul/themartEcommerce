<?php $__env->startSection('content'); ?>
<div class="col-lg-8">
    <div class="card">
        <div class="card-header">
            <h4>Edit Category</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('category.update')); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
               <div class="mb-3">
                <label for="category_name">Category Name:</label>
                <input type="hidden" name="category_id" value="<?php echo e($category_info->id); ?>">
                <input type="text" name="category_name" id="category_name" class="form-control" placeholder="Edit Category" value="<?php echo e($category_info->category_name); ?>">
               </div>
               <div class="mb-3">
                <label for="category_img">Category Image:</label>
                <input type="file" name="category_img" id="category_img" class="form-control">
               </div>
               <div class="mb-3">
                <button type="submit" class="btn btn-primary">Submit</button>
               </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COMPUTER WORLD\Desktop\creative\lara-app\resources\views/category/category_edit.blade.php ENDPATH**/ ?>