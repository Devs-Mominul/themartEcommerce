<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">Product List</div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Brand</th>
                    <th>P_Name</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <th>After Discount</th>

                    <th>preview</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->rel_to_category->category_name); ?></td>
                    <td><?php echo e($product->rel_to_subcategory->subcategory_name); ?></td>
                    <td><?php echo e($product->rel_to_brand->brand_name); ?></td>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->discount); ?></td>
                    <td><?php echo e($product->after_discount); ?></td>
                    <td>
                        <img width="40px" src="<?php echo e(asset('uploads/product/preview/')); ?>/<?php echo e($product->preview); ?>" alt=""></td>
                    <td>
                       <div class="d-flex">
                        <a  href="<?php echo e(route('product.delete',$product->id)); ?>" class="shadow btn btn-danger btn-xs sharp del_btn"><i class="fa fa-trash"></i></a>
                        <a  href="<?php echo e(route('product.show',$product->id)); ?>" class="shadow btn btn-info btn-xs sharp del_btn"><i class="fa fa-eye"></i></a>
                       </div>
                    </td>

                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COMPUTER WORLD\Desktop\creative\lara-app\resources\views/product/product_list.blade.php ENDPATH**/ ?>