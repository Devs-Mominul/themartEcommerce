<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">Show Product</div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <td>Product Name</td>
                    <td><?php echo e($product->product_name); ?></td>
                </tr>
                <tr>
                    <td>Product price</td>
                    <td><?php echo e($product->price); ?></td>
                </tr>
                <tr>
                    <td>Short Desp</td>
                    <td><?php echo e($product->short_desp); ?></td>
                </tr>
                <tr>
                    <td>long Desp</td>
                    <td>{<?php echo $product->long_desp; ?>}</td>
                </tr>
                <tr>
                    <td>Additional Info</td>
                    <td>{<?php echo $product->addi_info; ?>}</td>
                </tr>
                <tr>
                    <td>Preview</td>
                    <td><img width='150' src="<?php echo e(asset('uploads/product/preview/')); ?>/<?php echo e($product->preview); ?>" alt=""></td>
                </tr>
                <tr>
                    <td>Galldery</td>
                    <td>
                        <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img  width='200'height='200' src="<?php echo e(asset('uploads/gallery/')); ?>/<?php echo e($gal->gallery_image); ?>" alt="">

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>



            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COMPUTER WORLD\Desktop\creative\lara-app\resources\views/product/product_show.blade.php ENDPATH**/ ?>