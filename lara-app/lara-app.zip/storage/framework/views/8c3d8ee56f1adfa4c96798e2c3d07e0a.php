<?php $__env->startSection('content'); ?>
<div class="col-lg-6">
    <div class="card">
        <div class="card-header">Admin Dashboard</div>
        <div class="card-body">
            <h4>Welcome To Dashboard <span class="text-info"><?php echo e(Auth::user()->name); ?></span></h4>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COMPUTER WORLD\Desktop\creative\lara-app\resources\views/dashboard.blade.php ENDPATH**/ ?>